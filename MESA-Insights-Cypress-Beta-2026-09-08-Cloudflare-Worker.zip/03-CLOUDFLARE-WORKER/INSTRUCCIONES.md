# Portal completo para Cloudflare Workers

Esta compilación conserva las rutas dinámicas, los archivos del portal y el Evaluador integrado. Debe publicarse como **Cloudflare Worker con Assets**; no funciona como una página estática arrastrada a `public_html`.

## Publicación

1. Instale Node.js 22.13 o superior.
2. Inicie sesión en su cuenta de Cloudflare.
3. Abra una terminal en esta carpeta.
4. Ejecute `PUBLICAR-CLOUDFLARE-MAC-LINUX.sh` o `PUBLICAR-CLOUDFLARE-WINDOWS.bat`.
5. En Cloudflare, asigne el dominio definitivo al Worker `mesa-insights-cypress-beta`.

Los scripts descargan temporalmente Wrangler 4.92.0 y publican usando `wrangler.jsonc`. Cloudflare solicitará autorización si todavía no existe una sesión.

No copie la carpeta `server` dentro de un directorio web público. El Worker debe conservar juntos `server` y `client` como aparecen aquí.

La compilación está en modo demo. Para datos reales se debe configurar Supabase en el código fuente y volver a compilar antes de publicar.
