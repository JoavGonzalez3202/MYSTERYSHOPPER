/* global caches, fetch, self */

// This worker is intentionally an app-shell cache, not an offline data layer.
// Drafts and authenticated data keep using the application's existing storage
// and synchronization code. Bump this value only when the cache policy itself
// or a stable public shell asset changes.
const SHELL_CACHE_VERSION = 'v2';
const SHELL_CACHE_PREFIX = 'mesa-pwa-shell-';
const SHELL_CACHE_NAME = `${SHELL_CACHE_PREFIX}${SHELL_CACHE_VERSION}`;
const SERVICE_WORKER_SCOPE_PATH = new URL(
  self.registration?.scope ?? `${self.location.origin}/`,
).pathname.replace(/\/$/, '');

function scopedPath(path) {
  return `${SERVICE_WORKER_SCOPE_PATH}${path}`;
}

function pathnameWithinScope(pathname) {
  if (!SERVICE_WORKER_SCOPE_PATH) return pathname;
  if (pathname === SERVICE_WORKER_SCOPE_PATH) return '/';
  if (!pathname.startsWith(`${SERVICE_WORKER_SCOPE_PATH}/`)) return null;
  return pathname.slice(SERVICE_WORKER_SCOPE_PATH.length) || '/';
}

const ROOT_DOCUMENT_PATHS = new Set(['/', '/index.html']);
const APP_NAVIGATION_PATHS = new Set([
  '/account',
  '/drafts',
  '/forgot-password',
  '/history',
  '/sign-in',
  '/visits',
]);
const APP_NAVIGATION_PREFIXES = ['/evaluation/', '/summary/', '/visit/'];
const SENSITIVE_NAVIGATION_PREFIXES = ['/reset-password'];
const SAFE_PUBLIC_PATHS = new Set([
  '/favicon.ico',
  '/manifest.webmanifest',
  '/icons/icon-180.png',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/maskable-icon-512.png',
]);
const EXPO_STATIC_PREFIX = '/_expo/static/';
const PRECACHE_PATHS = [
  '/',
  '/index.html',
  '/favicon.ico',
  '/manifest.webmanifest',
  '/icons/icon-180.png',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/maskable-icon-512.png',
].map(scopedPath);

function expoStaticPathsFromHtml(html) {
  const paths = new Set();
  const assetPattern = /(?:src|href)=["']([^"'?#\s]*\/_expo\/static\/[^"'?#\s]+)["']/g;
  let match;
  while ((match = assetPattern.exec(html)) !== null) {
    if (match[1].startsWith(scopedPath('/_expo/static/'))) paths.add(match[1]);
  }
  return [...paths];
}

async function precacheAppShell() {
  const cache = await caches.open(SHELL_CACHE_NAME);
  await cache.addAll(PRECACHE_PATHS);

  // On the first visit a newly installed worker does not yet control the page,
  // so runtime caching cannot see the hashed Expo bundle that bootstraps React.
  // Discover those build-owned assets from the already cached public document
  // and cache them during install. Without this step the offline HTML would show
  // only its server-rendered loading state until the second online visit.
  const documentResponse =
    (await cache.match(scopedPath('/index.html'))) ??
    (await cache.match(scopedPath('/')));
  if (!documentResponse) throw new Error('MESA PWA shell document is unavailable');

  const expoStaticPaths = expoStaticPathsFromHtml(await documentResponse.text());
  if (expoStaticPaths.length === 0) {
    throw new Error('MESA PWA shell has no Expo static assets');
  }
  await cache.addAll(expoStaticPaths);
}

function parseSameOriginGetUrl(request) {
  if (request.method !== 'GET') return null;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return null;
  const scopedPathname = pathnameWithinScope(url.pathname);
  if (scopedPathname === null) return null;
  url.pathname = scopedPathname;
  return url;
}

function isRootDocumentRequest(request, url) {
  return request.mode === 'navigate' && !url.search && ROOT_DOCUMENT_PATHS.has(url.pathname);
}

function isSafeStaticRequest(request, url) {
  if (request.mode === 'navigate' || url.search) return false;
  return SAFE_PUBLIC_PATHS.has(url.pathname) || url.pathname.startsWith(EXPO_STATIC_PREFIX);
}

function isAppNavigationRequest(request, url) {
  if (request.mode !== 'navigate') return false;
  if (SENSITIVE_NAVIGATION_PREFIXES.some((prefix) => url.pathname.startsWith(prefix))) {
    return false;
  }
  return (
    APP_NAVIGATION_PATHS.has(url.pathname) ||
    APP_NAVIGATION_PREFIXES.some((prefix) => url.pathname.startsWith(prefix))
  );
}

function shouldHandleRequest(request) {
  const url = parseSameOriginGetUrl(request);
  if (!url) return false;
  return (
    isRootDocumentRequest(request, url) ||
    isSafeStaticRequest(request, url) ||
    isAppNavigationRequest(request, url)
  );
}

function mayStoreResponse(response) {
  if (!response || !response.ok || response.status !== 200) return false;
  if (response.type !== 'basic' || response.redirected) return false;

  const cacheControl = response.headers.get('cache-control')?.toLowerCase() ?? '';
  return !cacheControl.includes('no-store') && !cacheControl.includes('private');
}

async function storeIfSafe(cache, request, response) {
  if (mayStoreResponse(response)) {
    await cache.put(request, response.clone());
  }
  return response;
}

async function networkFirst(request) {
  const cache = await caches.open(SHELL_CACHE_NAME);
  try {
    const response = await fetch(request);
    return await storeIfSafe(cache, request, response);
  } catch (error) {
    const cached = await cache.match(request);
    if (cached) return cached;
    throw error;
  }
}

async function cacheFirst(request) {
  const cache = await caches.open(SHELL_CACHE_NAME);
  const cached = await cache.match(request);
  if (cached) return cached;

  const response = await fetch(request);
  return storeIfSafe(cache, request, response);
}

async function networkWithShellFallback(request) {
  try {
    // The route response is returned directly and is never written to Cache Storage.
    return await fetch(request);
  } catch (error) {
    const cache = await caches.open(SHELL_CACHE_NAME);
    const shell =
      (await cache.match(scopedPath('/'))) ??
      (await cache.match(scopedPath('/index.html')));
    if (shell) return shell;
    throw error;
  }
}

self.addEventListener('install', (event) => {
  event.waitUntil(precacheAppShell());
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((names) =>
        Promise.all(
          names
            .filter((name) => name.startsWith(SHELL_CACHE_PREFIX) && name !== SHELL_CACHE_NAME)
            .map((name) => caches.delete(name)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') void self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (!shouldHandleRequest(request)) return;

  const url = parseSameOriginGetUrl(request);
  if (!url) return;
  event.respondWith(
    isRootDocumentRequest(request, url)
      ? networkFirst(request)
      : isAppNavigationRequest(request, url)
        ? networkWithShellFallback(request)
        : cacheFirst(request),
  );
});
