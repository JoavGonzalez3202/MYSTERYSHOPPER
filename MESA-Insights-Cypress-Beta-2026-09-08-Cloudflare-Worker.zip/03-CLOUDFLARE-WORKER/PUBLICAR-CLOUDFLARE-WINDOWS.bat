@echo off
cd /d "%~dp0"
where npx >nul 2>nul
if errorlevel 1 (
  echo No se encontro npx. Instale Node.js 22.13 o superior.
  exit /b 1
)

npx --yes wrangler@4.92.0 deploy --config wrangler.jsonc
