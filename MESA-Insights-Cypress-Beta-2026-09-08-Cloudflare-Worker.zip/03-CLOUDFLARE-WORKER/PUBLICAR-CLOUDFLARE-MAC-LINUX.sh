#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR"

if ! command -v npx >/dev/null 2>&1; then
  echo "No se encontró npx. Instale Node.js 22.13 o superior."
  exit 1
fi

npx --yes wrangler@4.92.0 deploy --config wrangler.jsonc
