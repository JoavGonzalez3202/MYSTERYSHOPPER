export default {
  "bootstrapScriptContent": "import(\"/_next/static/chunks/index-ktiRAccW.js\")",
  "clientReferenceDeps": {
    "f11b9697bf8d": {
      "js": [
        "/_next/static/chunks/page-xX9BY4sb.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js",
        "/_next/static/chunks/supabase-C1wT3Ztz.js",
        "/_next/static/chunks/link-CvW8xwlp.js",
        "/_next/static/chunks/query-DDhZxhdQ.js"
      ],
      "css": []
    },
    "b49ea5cf04c0": {
      "js": [
        "/_next/static/chunks/page-CIyiQ8Qe.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js",
        "/_next/static/chunks/auth-context-CCNZirNC.js",
        "/_next/static/chunks/supabase-C1wT3Ztz.js",
        "/_next/static/chunks/image-DQITYMsT.js"
      ],
      "css": []
    },
    "6f4a849c1137": {
      "js": [
        "/_next/static/chunks/comparisons-view-C2xhmfOv.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/operational-state-00SbYRQm.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/auth-context-CCNZirNC.js",
        "/_next/static/chunks/supabase-C1wT3Ztz.js",
        "/_next/static/chunks/operations-context-D646HUlG.js",
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js"
      ],
      "css": []
    },
    "e0d36f1bfdf2": {
      "js": [
        "/_next/static/chunks/dashboard-view-CK-vVoyX.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/operational-state-00SbYRQm.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/auth-context-CCNZirNC.js",
        "/_next/static/chunks/supabase-C1wT3Ztz.js",
        "/_next/static/chunks/operations-context-D646HUlG.js",
        "/_next/static/chunks/image-DQITYMsT.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/link-CvW8xwlp.js",
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js",
        "/_next/static/chunks/query-DDhZxhdQ.js"
      ],
      "css": []
    },
    "f50536c72628": {
      "js": [
        "/_next/static/chunks/projects-view-CMczGxK_.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/dialog-IO7McaMC.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/operational-state-00SbYRQm.js",
        "/_next/static/chunks/auth-context-CCNZirNC.js",
        "/_next/static/chunks/supabase-C1wT3Ztz.js",
        "/_next/static/chunks/operations-context-D646HUlG.js",
        "/_next/static/chunks/link-CvW8xwlp.js",
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js",
        "/_next/static/chunks/query-DDhZxhdQ.js"
      ],
      "css": []
    },
    "fb94a3df80bf": {
      "js": [
        "/_next/static/chunks/protected-area-YvgyuYvr.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js",
        "/_next/static/chunks/unsaved-changes-provider-BbItv_ln.js",
        "/_next/static/chunks/auth-context-CCNZirNC.js",
        "/_next/static/chunks/supabase-C1wT3Ztz.js",
        "/_next/static/chunks/operations-context-D646HUlG.js",
        "/_next/static/chunks/image-DQITYMsT.js",
        "/_next/static/chunks/link-CvW8xwlp.js",
        "/_next/static/chunks/query-DDhZxhdQ.js"
      ],
      "css": []
    },
    "9f3470c1a4c1": {
      "js": [
        "/_next/static/chunks/questionnaire-builder-fs02KtwB.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/dialog-IO7McaMC.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/operational-state-00SbYRQm.js",
        "/_next/static/chunks/product-photo-comparison-CBmxErPp.js",
        "/_next/static/chunks/unsaved-changes-provider-BbItv_ln.js",
        "/_next/static/chunks/auth-context-CCNZirNC.js",
        "/_next/static/chunks/supabase-C1wT3Ztz.js",
        "/_next/static/chunks/operations-context-D646HUlG.js",
        "/_next/static/chunks/image-DQITYMsT.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js"
      ],
      "css": []
    },
    "089303cd5c17": {
      "js": [
        "/_next/static/chunks/result-detail-CHkMIOyl.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/operational-state-00SbYRQm.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/product-photo-comparison-CBmxErPp.js",
        "/_next/static/chunks/auth-context-CCNZirNC.js",
        "/_next/static/chunks/supabase-C1wT3Ztz.js",
        "/_next/static/chunks/operations-context-D646HUlG.js",
        "/_next/static/chunks/link-CvW8xwlp.js",
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js",
        "/_next/static/chunks/query-DDhZxhdQ.js"
      ],
      "css": []
    },
    "c8045fcaa808": {
      "js": [
        "/_next/static/chunks/results-view-lZbBWFJN.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/operational-state-00SbYRQm.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/auth-context-CCNZirNC.js",
        "/_next/static/chunks/supabase-C1wT3Ztz.js",
        "/_next/static/chunks/operations-context-D646HUlG.js",
        "/_next/static/chunks/link-CvW8xwlp.js",
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js",
        "/_next/static/chunks/query-DDhZxhdQ.js"
      ],
      "css": []
    },
    "2b22aee2d9f2": {
      "js": [
        "/_next/static/chunks/visits-view-Cf8hn_ps.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/dialog-IO7McaMC.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/operational-state-00SbYRQm.js",
        "/_next/static/chunks/auth-context-CCNZirNC.js",
        "/_next/static/chunks/supabase-C1wT3Ztz.js",
        "/_next/static/chunks/operations-context-D646HUlG.js",
        "/_next/static/chunks/link-CvW8xwlp.js",
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js",
        "/_next/static/chunks/query-DDhZxhdQ.js"
      ],
      "css": []
    },
    "cb4986b83daa": {
      "js": [
        "/_next/static/chunks/auth-context-CCNZirNC.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/supabase-C1wT3Ztz.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js"
      ],
      "css": []
    },
    "339390639513": {
      "js": [
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js"
      ],
      "css": []
    },
    "6ee896627c71": {
      "js": [
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js"
      ],
      "css": []
    },
    "c28d66e89eff": {
      "js": [
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js"
      ],
      "css": []
    },
    "16ee11233ed7": {
      "js": [
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js"
      ],
      "css": []
    },
    "4fbe1344b30a": {
      "js": [
        "/_next/static/chunks/layout-segment-context-VKACJLLD.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js"
      ],
      "css": []
    },
    "f457fe9dc781": {
      "js": [
        "/_next/static/chunks/index-ktiRAccW.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BaE7mD_r.js",
        "/_next/static/chunks/app-elements-Drg5O4vw.js",
        "/_next/static/chunks/hash-D0ldriCF.js",
        "/_next/static/chunks/record-BdkTR7AP.js",
        "/_next/static/chunks/app-rsc-cache-busting-12gRzt4l.js",
        "/_next/static/chunks/app-rsc-render-mode-IDJu5NEE.js",
        "/_next/static/chunks/headers-MnPyToYO.js",
        "/_next/static/chunks/protocol-headers-BwkNXebS.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-wvgRKjB-.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/index.h94Z2pRY.css"
      ]
    }
  }
}